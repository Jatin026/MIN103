in>>s;
        sum+=s.size();