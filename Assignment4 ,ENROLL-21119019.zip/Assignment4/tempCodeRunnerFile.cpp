
        }
    
        else if(c==2){
            counter2++;
        }
        else {
            counter1++;